import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from app.main import app
from app.database import Base, get_db
from app.services.knowledge_base import kb_service

# Create isolated in-memory database for testing
TEST_DATABASE_URL = "sqlite:///:memory:"
test_engine = create_engine(
    TEST_DATABASE_URL,
    connect_args={"check_same_thread": False},
    poolclass=StaticPool
)
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=test_engine)

def override_get_db():
    db = TestingSessionLocal()
    try:
        yield db
    finally:
        db.close()

app.dependency_overrides[get_db] = override_get_db

@pytest.fixture(autouse=True)
def setup_database():
    """Create fresh tables for every test."""
    Base.metadata.create_all(bind=test_engine)
    yield
    Base.metadata.drop_all(bind=test_engine)

client = TestClient(app)

def test_health_check_endpoint():
    """Verify system health endpoint returns operational status and loaded KB count >= 10."""
    response = client.get("/api/health")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "online"
    assert "healthy" in data["database_status"].lower()
    assert data["kb_items_count"] >= 10

def test_knowledge_base_count_and_retrieval():
    """Verify that knowledge base contains at least 10 items and search works correctly."""
    # Test retrieving all items
    response = client.get("/api/knowledge-base")
    assert response.status_code == 200
    items = response.json()
    assert len(items) >= 10

    # Test searching for VPN
    vpn_response = client.get("/api/knowledge-base?q=vpn")
    assert vpn_response.status_code == 200
    vpn_results = vpn_response.json()
    assert len(vpn_results) > 0
    assert any("vpn" in item["title"].lower() or "vpn" in item["problem_statement"].lower() for item in vpn_results)

    # Test searching for port conflict
    port_response = client.get("/api/knowledge-base?q=port+8000+in+use")
    assert port_response.status_code == 200
    port_results = port_response.json()
    assert len(port_results) > 0
    assert any("port" in item["title"].lower() for item in port_results)

def test_ticket_creation_and_persistence():
    """Verify ticket creation stores question, retrieved context, and AI response in DB."""
    payload = {
        "question": "How do I fix a port 8000 already in use error on my development machine?",
        "user_name": "Dev User",
        "category": "Developer Tools"
    }
    response = client.post("/api/tickets", json=payload)
    assert response.status_code == 201
    ticket = response.json()

    # Verify required database fields
    assert "id" in ticket
    assert ticket["ticket_code"].startswith("IT-")
    assert ticket["user_name"] == "Dev User"
    assert ticket["question"] == payload["question"]
    assert len(ticket["retrieved_context"]) > 10
    assert len(ticket["ai_response"]) > 10
    assert ticket["status"] == "OPEN"

    # Verify listing tickets returns the newly created ticket
    list_response = client.get("/api/tickets")
    assert list_response.status_code == 200
    list_data = list_response.json()
    assert list_data["total"] >= 1
    assert any(t["ticket_code"] == ticket["ticket_code"] for t in list_data["tickets"])

    # Verify fetching ticket by single ID
    ticket_id = ticket["id"]
    get_response = client.get(f"/api/tickets/{ticket_id}")
    assert get_response.status_code == 200
    assert get_response.json()["ticket_code"] == ticket["ticket_code"]

def test_ticket_input_validation_empty_or_short():
    """Verify validation rejects empty or too short questions with 422."""
    # Empty question
    res_empty = client.post("/api/tickets", json={"question": ""})
    assert res_empty.status_code == 422

    # Short whitespace question
    res_short = client.post("/api/tickets", json={"question": "   hi  "})
    assert res_short.status_code == 422

    # Valid question succeeds
    res_valid = client.post("/api/tickets", json={"question": "Why is my VPN disconnecting continuously?"})
    assert res_valid.status_code == 201

def test_ticket_not_found():
    """Verify 404 response for nonexistent ticket ID."""
    response = client.get("/api/tickets/999999")
    assert response.status_code == 404
    assert "not found" in response.json()["detail"].lower()

def test_tfidf_vector_similarity_accuracy():
    """Test TF-IDF cosine similarity retrieves accurate documents."""
    results = kb_service.search("blue screen memory management crash", top_k=1)
    assert len(results) > 0
    top_doc, score = results[0]
    assert "blue screen" in top_doc["title"].lower() or "bsod" in top_doc["keywords"]
    assert score > 0.1
