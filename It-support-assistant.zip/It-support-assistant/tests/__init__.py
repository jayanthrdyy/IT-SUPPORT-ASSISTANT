"""Test suite package for AI IT Support Assistant."""
