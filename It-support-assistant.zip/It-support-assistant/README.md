# 🛠️ AI-Powered IT Support Assistant

> An enterprise-grade, automated IT Helpdesk and Troubleshooting Assistant built with **FastAPI**, **SQLAlchemy + SQLite**, **TF-IDF Vector RAG Retrieval**, and **Dual LLM Integration (Google Gemini & Groq)**.

Designed specifically for on-campus technical drive evaluations, adhering to production standards with modular architecture, strict input validation, resilient offline demo fallback, automated unit tests, and containerization.

---

## 🏗️ System Architecture

```
                                  +------------------------------------+
                                  |     Clean Web Dashboard UI         |
                                  |  (HTML5 / Modern CSS / Vanilla JS) |
                                  +-----------------+------------------+
                                                    |
                                                    | HTTP REST / JSON
                                                    v
+---------------------------------------------------------------------------------------------------+
|                                        FastAPI Backend                                            |
|                                                                                                   |
|   +-----------------------+     +-------------------------------+     +-----------------------+   |
|   |   API Endpoints       | --> | Ticket Service                | --> | Database (SQLite)     |   |
|   |   - POST /api/tickets |     | - Input validation (Pydantic) |     | - Tickets Table       |   |
|   |   - GET  /api/tickets |     | - Orchestration & logging     |     |   (Question, Context, |   |
|   |   - GET  /api/tickets/{id}  +---------------+---------------+     |    AI Response, Meta) |   |
|   |   - GET  /api/kb      |                     |                     +-----------------------+   |
|   |   - GET  /api/health  |                     |                                                 |
|   +-----------------------+                     v                                                 |
|                                     +-----------------------+                                     |
|                                     | Knowledge Base Engine |                                     |
|                                     | - 12+ IT Solved Cases |                                     |
|                                     | - TF-IDF + Cosine Sim |                                     |
|                                     |   Vector Search       |                                     |
|                                     +-----------+-----------+                                     |
|                                                 |                                                 |
|                                                 v                                                 |
|                                     +-----------------------+                                     |
|                                     | LLM Service           |                                     |
|                                     | - Google Gemini       |                                     |
|                                     | - Groq Llama 3        |                                     |
|                                     | - Fallback RAG Mock   |                                     |
|                                     +-----------------------+                                     |
+---------------------------------------------------------------------------------------------------+
```

---

## ✨ Key Features

1. **Intelligent RAG Knowledge Base**:
   - Contains **12 pre-indexed enterprise IT solutions** covering VPN drops, port conflicts (`EADDRINUSE`), DNS caching, Print Spooler crashes, Git merge conflicts, SSH key permissions, BSOD memory crashes, Outlook OST sync, Docker daemon failures, low disk space, account lockouts, and runaway CPU processes.
   - Uses **TF-IDF Vectorizer + Cosine Similarity** (`scikit-learn`) for sub-millisecond semantic retrieval with tech-keyword boosting.

2. **Dual Free-Tier LLM Support**:
   - **Google Gemini API**: Native integration using official `google-genai` SDK (`gemini-1.5-flash`).
   - **Groq API**: High-speed inference using `groq` SDK (`llama-3.1-8b-instant`).
   - **Offline Demo Resilience**: If no API key is provided during live testing, the system automatically falls back to an intelligent offline RAG synthesizer, ensuring zero downtime in front of interviewers.

3. **Complete Database Persistence**:
   - SQLite backed by **SQLAlchemy ORM**.
   - Persists: `ticket_code` (e.g., `IT-4821`), `user_name`, `question`, `category`, `retrieved_context`, `ai_response`, `llm_provider`, `status`, and `created_at`.

4. **Clean, Responsive Dashboard UI**:
   - **Single Page Interface**: Served directly by FastAPI at `http://127.0.0.1:8000/`. Zero npm/node build steps required.
   - **Quick-Prompt Chips**: One-click sample issues for rapid testing.
   - **Live Progress & Error Handling**: Loading spinners, character counters, and user-friendly error banners.
   - **RAG Evidence Viewer**: Collapsible accordion showing the exact knowledge base context fed into the LLM.
   - **Ticket History & Modal**: Real-time searchable history of all logged tickets.
   - **Knowledge Base Explorer**: Interactive tab to search and inspect standard operating procedures.

5. **Automated Testing Suite**:
   - Comprehensive `pytest` test suite verifying health checks, input validation, RAG accuracy, and DB operations.

---

## 🚀 Quickstart Guide

### Prerequisites
- Python 3.10+ (Python 3.11 recommended)
- Optional: Free Gemini API Key ([Google AI Studio](https://aistudio.google.com/app/apikey)) or Groq API Key ([Groq Console](https://console.groq.com/keys))

### 1. Installation

```bash
# Clone or navigate into the project directory
cd ai-it-support-assistant

# Install dependencies
pip install -r requirements.txt
```

### 2. Configure Environment (Optional for Demo Mode)

Copy `.env.example` to `.env`:

```bash
# Windows PowerShell
Copy-Item .env.example .env

# Linux / macOS
cp .env.example .env
```

Open `.env` and add your API key (if you have one):
```env
LLM_PROVIDER=gemini
GEMINI_API_KEY=your_free_gemini_api_key_here
# or
# LLM_PROVIDER=groq
# GROQ_API_KEY=your_free_groq_api_key_here
```
> *Note: If no key is set, the application automatically runs in **Offline Demo Mode**.*

### 3. Run the Application

```bash
uvicorn app.main:app --host 127.0.0.1 --port 8001 --reload
```

Open your web browser and visit:
- **Web Dashboard**: [http://127.0.0.1:8001/](http://127.0.0.1:8001/)
- **Interactive Swagger API Docs**: [http://127.0.0.1:8001/docs](http://127.0.0.1:8001/docs)
- **ReDoc API Docs**: [http://127.0.0.1:8001/redoc](http://127.0.0.1:8001/redoc)

---

## 🧪 Running Automated Tests

Run the test suite using `pytest`:

```bash
python -m pytest tests/test_app.py -v
```

All tests execute against an isolated in-memory SQLite database (`sqlite:///:memory:`).

---

## 🐳 Docker Deployment (Optional Bonus)

Run the application inside a lightweight container:

```bash
# Using Docker Compose
docker-compose up --build -d

# Or using plain Docker
docker build -t ai-it-support-assistant .
docker run -p 8000:8000 -e GEMINI_API_KEY="your_key" ai-it-support-assistant
```

---

## 📡 REST API Reference

| Method | Endpoint | Description |
|---|---|---|
| `POST` | `/api/tickets` | Submits issue, runs RAG, generates AI solution, and saves ticket |
| `GET` | `/api/tickets` | Lists logged tickets (supports `?limit=50&search=keyword`) |
| `GET` | `/api/tickets/{ticket_id}` | Retrieves details of a specific ticket by ID |
| `GET` | `/api/knowledge-base` | Returns all KB articles or searches via TF-IDF (`?q=term`) |
| `GET` | `/api/health` | Returns health status, DB connectivity, and active engine |

### Example Request (`POST /api/tickets`):

```bash
curl -X POST "http://127.0.0.1:8001/api/tickets" \
  -H "Content-Type: application/json" \
  -d '{
    "question": "How do I fix a port 8000 already in use error on Windows?",
    "user_name": "Jayanth",
    "category": "Developer Tools"
  }'
```

### Example Response:

```json
{
  "id": 1,
  "ticket_code": "IT-4821",
  "user_name": "Jayanth",
  "question": "How do I fix a port 8000 already in use error on Windows?",
  "category": "Developer Tools",
  "retrieved_context": "### Document 1: TCP Port Already in Use...",
  "ai_response": "### 🛠️ IT Diagnostic & Troubleshooting Guide\n\n**Diagnostic Summary**:\nYour port 8000 is occupied by a background process...",
  "llm_provider": "gemini (gemini-1.5-flash)",
  "status": "OPEN",
  "created_at": "2026-09-16T17:40:00.000000"
}
```

---

## 🎓 Campus Drive Technical Interview Defense & FAQs

Here are concise answers to questions evaluators frequently ask:

### Q1: Why did you choose TF-IDF Vector Retrieval instead of PyTorch / HuggingFace embeddings?
> **Answer**:
> 1. **Zero Deployment Bloat**: PyTorch or sentence-transformers add 1.5GB to the environment and take minutes to initialize.
> 2. **Instant Sub-Millisecond Search**: TF-IDF with cosine similarity runs entirely in-memory via `scikit-learn` in under 1ms, ideal for high-throughput microservices.
> 3. **Deterministic & Inspectable**: Unlike black-box embeddings, TF-IDF weights are easily explainable and allow explicit tech-keyword boosting (e.g., port numbers, error codes).

### Q2: How does Retrieval-Augmented Generation (RAG) improve IT support?
> **Answer**:
> General-purpose LLMs frequently hallucinate command-line flags or outdated operating system steps. RAG anchors the LLM with verified enterprise documentation in the prompt context, guaranteeing that the model quotes verified company procedures and commands.

### Q3: How is input validation handled?
> **Answer**:
> Pydantic v2 schemas (`TicketCreate`) enforce minimum length (5 non-whitespace characters), maximum length (2000 chars), sanitization, and data typing before the request reaches business logic, returning HTTP 422 Unprocessable Entity on violations.

### Q4: How do you handle API downtime or missing keys?
> **Answer**:
> `app/services/llm_service.py` implements a graceful degradation pattern:
> 1. Tries the configured provider (Gemini or Groq).
> 2. If an exception or rate-limit occurs, it catches the error and falls back to a structured local RAG synthesis engine.
> 3. The system never crashes or returns a 500 error due to external LLM downtime.

---

## 📂 Project Structure

```
ai-it-support-assistant/
├── app/
│   ├── __init__.py
│   ├── main.py                   # FastAPI app, CORS, static mounting, lifespan
│   ├── config.py                 # Pydantic Settings & environment variables
│   ├── database.py               # SQLite engine, sessionmaker, Base
│   ├── models.py                 # SQLAlchemy models (Ticket)
│   ├── schemas.py                # Pydantic validation schemas
│   ├── services/
│   │   ├── __init__.py
│   │   ├── knowledge_base.py     # 12+ IT items + TF-IDF Vector/Cosine Similarity search
│   │   ├── llm_service.py        # Gemini + Groq integration + fallback mock
│   │   └── ticket_service.py     # Business logic coordinating DB + KB + LLM
│   ├── api/
│   │   ├── __init__.py
│   │   └── routes.py             # REST endpoints (/tickets, /kb, /health)
│   └── static/
│       ├── index.html            # Clean, responsive single-page portal
│       ├── css/
│       │   └── style.css         # Modern typography, cards, badges, and modals
│       └── js/
│           └── app.js            # Client-side state, API calls, and markdown parsing
├── data/
│   └── knowledge_base.json       # 12 detailed IT troubleshooting SOPs
├── tests/
│   ├── __init__.py
│   └── test_app.py               # Automated pytest suite (DB, API, RAG, validation)
├── .env.example                  # Environment configuration template
├── Dockerfile                    # Multi-stage production containerfile
├── docker-compose.yml            # Container orchestration config
├── requirements.txt              # Pinned Python package dependencies
└── README.md                     # Comprehensive documentation & interview defense
```
