"""AI-Powered IT Support Assistant Application Package"""
__version__ = "1.0.0"
