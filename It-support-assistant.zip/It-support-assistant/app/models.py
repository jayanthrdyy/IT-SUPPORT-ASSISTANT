from datetime import datetime, timezone
from sqlalchemy import Column, Integer, String, Text, DateTime
from app.database import Base

class Ticket(Base):
    __tablename__ = "tickets"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    ticket_code = Column(String(32), unique=True, index=True, nullable=False)
    user_name = Column(String(100), default="Employee", nullable=False)
    question = Column(Text, nullable=False)
    category = Column(String(100), default="General IT", nullable=False)
    retrieved_context = Column(Text, nullable=False)
    ai_response = Column(Text, nullable=False)
    llm_provider = Column(String(50), default="auto", nullable=False)
    status = Column(String(20), default="OPEN", nullable=False)  # OPEN, RESOLVED, IN_PROGRESS
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc), nullable=False)

    def __repr__(self):
        return f"<Ticket {self.ticket_code} - {self.category}>"
