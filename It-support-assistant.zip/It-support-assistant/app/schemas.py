from datetime import datetime
from typing import List, Optional
from pydantic import BaseModel, Field, field_validator

class TicketCreate(BaseModel):
    question: str = Field(
        ...,
        min_length=5,
        max_length=2000,
        description="Technical support question or problem description",
        examples=["How do I fix a port 8000 already in use error on Windows?"]
    )
    user_name: Optional[str] = Field(
        default="Employee",
        max_length=100,
        description="Name of the user submitting the ticket"
    )
    category: Optional[str] = Field(
        default="General IT",
        max_length=100,
        description="Optional category hint"
    )

    @field_validator("question")
    @classmethod
    def validate_question_content(cls, v: str) -> str:
        cleaned = v.strip()
        if len(cleaned) < 5:
            raise ValueError("Question must be at least 5 non-whitespace characters long.")
        return cleaned

    @field_validator("user_name")
    @classmethod
    def clean_user_name(cls, v: Optional[str]) -> str:
        if not v or not v.strip():
            return "Employee"
        return v.strip()


class TicketResponse(BaseModel):
    id: int
    ticket_code: str
    user_name: str
    question: str
    category: str
    retrieved_context: str
    ai_response: str
    llm_provider: str
    status: str
    created_at: datetime

    model_config = {"from_attributes": True}


class TicketListResponse(BaseModel):
    total: int
    tickets: List[TicketResponse]


class KnowledgeBaseItem(BaseModel):
    id: str
    title: str
    category: str
    problem_statement: str
    keywords: List[str]
    root_cause: str
    solution_steps: List[str]
    quick_command: Optional[str] = None


class HealthResponse(BaseModel):
    status: str
    database_status: str
    kb_items_count: int
    active_provider: str
    gemini_configured: bool
    groq_configured: bool
