"""Services package for knowledge base, LLM orchestration, and ticketing."""
