import json
import logging
from pathlib import Path
from typing import List, Dict, Tuple, Any
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from app.config import settings

logger = logging.getLogger(__name__)

class KnowledgeBaseService:
    def __init__(self, kb_file_path: str = None):
        self.file_path = Path(kb_file_path or settings.KB_FILE_PATH)
        self.items: List[Dict[str, Any]] = []
        self.vectorizer: TfidfVectorizer = None
        self.tfidf_matrix = None
        self.load_and_index()

    def load_and_index(self):
        """Loads items from JSON file and builds the TF-IDF vector index."""
        if not self.file_path.exists():
            logger.error(f"Knowledge base file not found at {self.file_path}")
            self.items = []
            return

        try:
            with open(self.file_path, "r", encoding="utf-8") as f:
                self.items = json.load(f)
            logger.info(f"Loaded {len(self.items)} knowledge base items.")
        except Exception as e:
            logger.error(f"Error loading knowledge base: {e}")
            self.items = []
            return

        if not self.items:
            return

        # Prepare corpus for vectorization: combine title, keywords, problem statement, and root cause
        corpus = []
        for item in self.items:
            keywords_text = " ".join(item.get("keywords", []))
            solution_text = " ".join(item.get("solution_steps", []))
            doc_text = (
                f"{item.get('title', '')} "
                f"{item.get('category', '')} "
                f"{item.get('problem_statement', '')} "
                f"{keywords_text} "
                f"{item.get('root_cause', '')} "
                f"{solution_text}"
            )
            corpus.append(doc_text.lower())

        self.vectorizer = TfidfVectorizer(
            ngram_range=(1, 2),
            stop_words="english",
            sublinear_tf=True
        )
        self.tfidf_matrix = self.vectorizer.fit_transform(corpus)
        logger.info(f"Built TF-IDF index with vocabulary size: {len(self.vectorizer.vocabulary_)}")

    def search(self, query: str, top_k: int = 2) -> List[Tuple[Dict[str, Any], float]]:
        """
        Search knowledge base using TF-IDF vector similarity combined with exact keyword match boosts.
        Returns a list of (item, similarity_score) tuples.
        """
        if not self.items or self.vectorizer is None or self.tfidf_matrix is None:
            return []

        query_cleaned = query.lower().strip()
        query_vec = self.vectorizer.transform([query_cleaned])
        similarities = cosine_similarity(query_vec, self.tfidf_matrix).flatten()

        # Combine cosine similarity with keyword match boosting for tech terms (e.g. '8000', 'vpn', 'bsod')
        scored_items = []
        query_tokens = set(query_cleaned.split())

        for idx, item in enumerate(self.items):
            base_score = float(similarities[idx])
            boost = 0.0

            # Boost if specific keywords appear in item keywords
            item_keywords = [k.lower() for k in item.get("keywords", [])]
            for kw in item_keywords:
                if kw in query_cleaned or any(token == kw for token in query_tokens):
                    boost += 0.15

            final_score = base_score + boost
            scored_items.append((item, final_score))

        # Sort by final score descending
        scored_items.sort(key=lambda x: x[1], reverse=True)
        return scored_items[:top_k]

    def format_context_for_llm(self, results: List[Tuple[Dict[str, Any], float]]) -> str:
        """Formats the retrieved KB items into a readable context string for the LLM prompt."""
        if not results:
            return "No specific internal troubleshooting documents matched the query."

        context_blocks = []
        for i, (item, score) in enumerate(results, 1):
            solutions_formatted = "\n".join(f"  {step}" for step in item.get("solution_steps", []))
            block = (
                f"### Document {i}: {item.get('title')} (Category: {item.get('category')}, Relevance Score: {score:.2f})\n"
                f"- **Problem**: {item.get('problem_statement')}\n"
                f"- **Likely Cause**: {item.get('root_cause')}\n"
                f"- **Verified Steps**:\n{solutions_formatted}\n"
            )
            if item.get("quick_command"):
                block += f"- **Quick Command**: `{item.get('quick_command')}`\n"
            context_blocks.append(block)

        return "\n".join(context_blocks)

    def get_all_items(self) -> List[Dict[str, Any]]:
        """Returns all knowledge base items."""
        return self.items


kb_service = KnowledgeBaseService()
