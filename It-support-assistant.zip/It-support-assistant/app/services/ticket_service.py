import random
import string
from typing import List, Optional
from sqlalchemy.orm import Session
from sqlalchemy import desc

from app.models import Ticket
from app.schemas import TicketCreate
from app.services.knowledge_base import kb_service
from app.services.llm_service import llm_service

def generate_ticket_code() -> str:
    """Generates a human-friendly ticket code e.g. IT-8492."""
    rand_digits = "".join(random.choices(string.digits, k=4))
    return f"IT-{rand_digits}"

class TicketService:
    def process_and_create_ticket(self, db: Session, ticket_in: TicketCreate) -> Ticket:
        """
        Orchestrates full RAG pipeline:
        1. Query KB for matching technical documentation via TF-IDF cosine similarity.
        2. Format retrieved context.
        3. Request LLM generation.
        4. Save to SQL Database.
        5. Return ticket record.
        """
        question = ticket_in.question.strip()

        # Step 1: Retrieve context from Knowledge Base
        kb_results = kb_service.search(question, top_k=2)
        retrieved_context = kb_service.format_context_for_llm(kb_results)

        # Detect category from top matched item if provided as default
        category = ticket_in.category or "General IT"
        if kb_results and category in ["General IT", None, ""]:
            top_item, score = kb_results[0]
            if score > 0.1:
                category = top_item.get("category", "General IT")

        # Step 2: Generate troubleshooting answer using LLM
        ai_response, provider_used = llm_service.generate_response(
            question=question,
            retrieved_context=retrieved_context
        )

        # Step 3: Ensure unique ticket code
        ticket_code = generate_ticket_code()
        while db.query(Ticket).filter(Ticket.ticket_code == ticket_code).first() is not None:
            ticket_code = generate_ticket_code()

        # Step 4: Persist in database
        db_ticket = Ticket(
            ticket_code=ticket_code,
            user_name=ticket_in.user_name or "Employee",
            question=question,
            category=category,
            retrieved_context=retrieved_context,
            ai_response=ai_response,
            llm_provider=provider_used,
            status="OPEN"
        )
        db.add(db_ticket)
        db.commit()
        db.refresh(db_ticket)

        return db_ticket

    def get_tickets(self, db: Session, skip: int = 0, limit: int = 50, search: Optional[str] = None) -> List[Ticket]:
        """Fetch list of tickets sorted by newest first with optional search."""
        query = db.query(Ticket)
        if search:
            search_filter = f"%{search}%"
            query = query.filter(
                (Ticket.question.ilike(search_filter)) |
                (Ticket.ticket_code.ilike(search_filter)) |
                (Ticket.category.ilike(search_filter))
            )
        return query.order_by(desc(Ticket.created_at)).offset(skip).limit(limit).all()

    def get_ticket_count(self, db: Session) -> int:
        """Get total count of tickets in database."""
        return db.query(Ticket).count()

    def get_ticket_by_id(self, db: Session, ticket_id: int) -> Optional[Ticket]:
        """Fetch single ticket by primary key ID."""
        return db.query(Ticket).filter(Ticket.id == ticket_id).first()


ticket_service = TicketService()
