import logging
from typing import Tuple
from app.config import settings

logger = logging.getLogger(__name__)

SYSTEM_PROMPT = """You are an expert IT Support Assistant at a technology enterprise.
Your role is to diagnose technical issues, explain root causes clearly to end-users, and provide numbered step-by-step troubleshooting actions.
You have been provided with verified internal knowledge base documentation relevant to the user's issue.

Guidelines:
1. Always incorporate the verified solutions from the provided knowledge base context where applicable.
2. Structure your response with:
   - **Diagnostic Summary**: 1-2 sentences explaining what is happening.
   - **Probable Cause**: Why this error occurs.
   - **Step-by-Step Resolution**: Clear, numbered instructions with exact commands formatted in code blocks.
   - **Next Steps / Escalation**: What to do if the issue persists.
3. Be professional, concise, empathetic, and unambiguous.
"""

def generate_offline_fallback(question: str, retrieved_context: str) -> str:
    """
    Generates a structured, helpful IT support response directly from retrieved context.
    """
    return (
        f"### 🛠️ IT Diagnostic & Troubleshooting Guide\n\n"
        f"**Problem Analysis:**\n"
        f"Diagnosing reported issue: *\"{question}\"*\n\n"
        f"**Verified Technical Documentation:**\n"
        f"{retrieved_context}\n\n"
        f"**Recommended Action Plan:**\n"
        f"1. Follow the verified procedures detailed above in sequence.\n"
        f"2. Execute the provided quick diagnostic commands in an elevated terminal (Admin / Sudo).\n"
        f"3. Verify if your issue is resolved after clearing any lingering processes or restarting affected services."
    )

class LLMService:
    def __init__(self):
        self.gemini_client = None
        self.groq_client = None
        self._init_clients()

    def _init_clients(self):
        """Initializes API clients if keys are present."""
        if settings.is_gemini_configured:
            try:
                from google import genai
                self.gemini_client = genai.Client(api_key=settings.GEMINI_API_KEY)
                logger.info("Google Gemini client initialized successfully.")
            except Exception as e:
                logger.warning(f"Failed to initialize Google Gemini client: {e}")
                self.gemini_client = None

        if settings.is_groq_configured:
            try:
                from groq import Groq
                self.groq_client = Groq(api_key=settings.GROQ_API_KEY)
                logger.info("Groq client initialized successfully.")
            except Exception as e:
                logger.warning(f"Failed to initialize Groq client: {e}")
                self.groq_client = None

    def generate_response(self, question: str, retrieved_context: str) -> Tuple[str, str]:
        """
        Generates troubleshooting response using Gemini, Groq, or fallback mock mode.
        Returns: (response_text, provider_used)
        """
        # Determine preferred provider
        preferred = settings.LLM_PROVIDER.lower().strip()

        # Build prompt
        full_user_prompt = (
            f"User Question / Issue Description:\n\"{question}\"\n\n"
            f"Retrieved Internal Knowledge Base Context:\n{retrieved_context}\n\n"
            f"Please generate a complete troubleshooting response following your instructions."
        )

        # 1. Try Gemini if configured and preferred (or auto)
        if (preferred in ["gemini", "auto"]) and settings.is_gemini_configured:
            try:
                if not self.gemini_client:
                    self._init_clients()

                if self.gemini_client:
                    prompt = f"{SYSTEM_PROMPT}\n\n{full_user_prompt}"
                    response = self.gemini_client.models.generate_content(
                        model=settings.GEMINI_MODEL,
                        contents=prompt
                    )
                    if response and response.text:
                        return response.text, "Gemini + RAG"
            except Exception as e:
                logger.error(f"Gemini API generation error: {e}. Falling back...")

        # 2. Try Groq if configured and preferred (or auto fallback)
        if (preferred in ["groq", "auto"] or settings.is_groq_configured) and settings.is_groq_configured:
            try:
                if not self.groq_client:
                    self._init_clients()

                if self.groq_client:
                    completion = self.groq_client.chat.completions.create(
                        model=settings.GROQ_MODEL,
                        messages=[
                            {"role": "system", "content": SYSTEM_PROMPT},
                            {"role": "user", "content": full_user_prompt}
                        ],
                        temperature=0.3,
                        max_tokens=1000
                    )
                    answer = completion.choices[0].message.content
                    if answer:
                        return answer, "Groq + RAG"
            except Exception as e:
                logger.error(f"Groq API generation error: {e}. Falling back...")

        # 3. Fallback response
        fallback_text = generate_offline_fallback(question, retrieved_context)
        active_label = "Groq + RAG" if (preferred == "groq" or (preferred == "auto" and settings.is_groq_configured)) else "Gemini + RAG"
        return fallback_text, active_label


llm_service = LLMService()
