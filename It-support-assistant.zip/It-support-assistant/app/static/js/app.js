document.addEventListener('DOMContentLoaded', () => {
  // Elements
  const form = document.getElementById('support-form');
  const questionInput = document.getElementById('question-input');
  const categorySelect = document.getElementById('category-select');
  const submitBtn = document.getElementById('submit-btn');
  const resetBtn = document.getElementById('reset-btn');
  const charCount = document.getElementById('char-count');
  const formAlert = document.getElementById('form-alert');

  const emptyState = document.getElementById('empty-state');
  const loadingState = document.getElementById('loading-state');
  const responseContent = document.getElementById('response-content');
  const ticketTag = document.getElementById('response-ticket-tag');
  const copyBtn = document.getElementById('copy-response-btn');

  const resCategory = document.getElementById('res-category');
  const resProvider = document.getElementById('res-provider');
  const resStatus = document.getElementById('res-status');
  const aiBodyText = document.getElementById('ai-body-text');

  const toggleRagBtn = document.getElementById('toggle-rag-btn');
  const ragContent = document.getElementById('rag-content');
  const ragArrow = document.getElementById('rag-arrow');
  const ragContextText = document.getElementById('rag-context-text');

  const historyTableBody = document.getElementById('tickets-table-body');
  const historySearch = document.getElementById('history-search');
  const refreshHistoryBtn = document.getElementById('refresh-history-btn');

  const kbCardsGrid = document.getElementById('kb-cards-grid');
  const kbSearchInput = document.getElementById('kb-search-input');
  const kbSearchBtn = document.getElementById('kb-search-btn');

  const modal = document.getElementById('ticket-modal');
  const modalTitle = document.getElementById('modal-title');
  const modalBody = document.getElementById('modal-body');
  const modalCloseBtn = document.getElementById('modal-close-btn');
  const modalBackdrop = document.getElementById('modal-backdrop');

  const statusPill = document.getElementById('status-pill');
  const providerPill = document.getElementById('provider-pill');
  const kbCountPill = document.getElementById('kb-count-pill');

  let currentAIResponseRaw = '';

  // 1. Initial Data Fetch
  fetchHealthStatus();
  fetchTicketsHistory();
  fetchKnowledgeBase();

  // 2. Tab Navigation
  const tabBtns = document.querySelectorAll('.tab-btn');
  tabBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      tabBtns.forEach(b => b.classList.remove('active'));
      document.querySelectorAll('.tab-pane').forEach(p => p.classList.add('hidden'));

      btn.classList.add('active');
      const targetPane = document.getElementById(btn.dataset.tab);
      if (targetPane) targetPane.classList.remove('hidden');

      if (btn.dataset.tab === 'history-tab') {
        fetchTicketsHistory();
      }
    });
  });

  // 3. Character Counter
  questionInput.addEventListener('input', () => {
    const len = questionInput.value.length;
    charCount.textContent = len;
    if (len >= 5) {
      hideAlert();
    }
  });

  // 4. Quick Template Chips
  document.querySelectorAll('.chip').forEach(chip => {
    chip.addEventListener('click', () => {
      questionInput.value = chip.dataset.text;
      charCount.textContent = questionInput.value.length;
      hideAlert();
      questionInput.focus();
    });
  });

  // 5. Reset Button
  resetBtn.addEventListener('click', () => {
    questionInput.value = '';
    charCount.textContent = '0';
    hideAlert();
  });

  // 6. Form Submission (POST /api/tickets)
  form.addEventListener('submit', async (e) => {
    e.preventDefault();

    const question = questionInput.value.trim();
    const category = categorySelect.value;

    if (question.length < 5) {
      showAlert('Please enter at least 5 characters describing the issue.', 'danger');
      questionInput.focus();
      return;
    }

    hideAlert();
    setLoading(true);

    try {
      const response = await fetch('/api/tickets', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          question: question,
          category: category
        })
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({ detail: 'Server error' }));
        throw new Error(errorData.detail || `Server error: ${response.status}`);
      }

      const ticket = await response.json();
      displayTicketResponse(ticket);
      fetchTicketsHistory(); // Refresh history in background
    } catch (err) {
      console.error('Submission error:', err);
      showAlert(`Submission Failed: ${err.message}`, 'danger');
      setLoading(false, true); // Keep empty state
    }
  });

  function setLoading(isLoading, retainCurrent = false) {
    const btnSpinner = submitBtn.querySelector('.btn-spinner');
    const btnText = submitBtn.querySelector('.btn-text');

    if (isLoading) {
      submitBtn.disabled = true;
      btnSpinner.classList.remove('hidden');
      btnText.textContent = 'Analyzing Issue & Searching KB...';
      emptyState.classList.add('hidden');
      responseContent.classList.add('hidden');
      loadingState.classList.remove('hidden');
      copyBtn.classList.add('hidden');
    } else {
      submitBtn.disabled = false;
      btnSpinner.classList.add('hidden');
      btnText.textContent = 'Generate Troubleshooting Plan';
      loadingState.classList.add('hidden');
      if (retainCurrent) {
        emptyState.classList.remove('hidden');
      }
    }
  }

  function displayTicketResponse(ticket) {
    setLoading(false);
    emptyState.classList.add('hidden');
    responseContent.classList.remove('hidden');
    copyBtn.classList.remove('hidden');

    ticketTag.textContent = `Ticket #${ticket.ticket_code}`;
    ticketTag.className = 'badge badge-primary';

    resCategory.textContent = ticket.category;
    resProvider.textContent = ticket.llm_provider;
    resStatus.textContent = ticket.status;

    currentAIResponseRaw = ticket.ai_response;
    aiBodyText.innerHTML = renderMarkdown(ticket.ai_response);
    ragContextText.textContent = ticket.retrieved_context;

    // Scroll to response on mobile
    if (window.innerWidth < 960) {
      document.getElementById('response-card').scrollIntoView({ behavior: 'smooth' });
    }
  }

  // 7. Toggle RAG Accordion
  toggleRagBtn.addEventListener('click', () => {
    const isHidden = ragContent.classList.contains('hidden');
    if (isHidden) {
      ragContent.classList.remove('hidden');
      ragArrow.textContent = '▲';
    } else {
      ragContent.classList.add('hidden');
      ragArrow.textContent = '▼';
    }
  });

  // 8. Copy Response to Clipboard
  copyBtn.addEventListener('click', () => {
    if (!currentAIResponseRaw) return;
    navigator.clipboard.writeText(currentAIResponseRaw).then(() => {
      const originalText = copyBtn.textContent;
      copyBtn.textContent = '✅ Copied!';
      setTimeout(() => {
        copyBtn.textContent = originalText;
      }, 2000);
    }).catch(err => {
      console.error('Failed to copy: ', err);
    });
  });

  // 9. Fetch Ticket History
  async function fetchTicketsHistory(searchQuery = '') {
    try {
      let url = '/api/tickets?limit=50';
      if (searchQuery) {
        url += `&search=${encodeURIComponent(searchQuery)}`;
      }
      const res = await fetch(url);
      if (!res.ok) throw new Error('Failed to fetch tickets');

      const data = await res.json();

      if (!data.tickets || data.tickets.length === 0) {
        historyTableBody.innerHTML = `
          <tr>
            <td colspan="6" class="text-center py-4 text-muted">
              ${searchQuery ? 'No tickets matching your search query.' : 'No support tickets logged yet. Submit your first ticket!'}
            </td>
          </tr>
        `;
        return;
      }

      historyTableBody.innerHTML = data.tickets.map(t => {
        const createdDate = new Date(t.created_at).toLocaleString();
        const shortQuestion = escapeHtml(t.question.length > 60 ? t.question.substring(0, 57) + '...' : t.question);
        return `
          <tr>
            <td><strong>${escapeHtml(t.ticket_code)}</strong></td>
            <td><span class="badge badge-neutral">${escapeHtml(t.category)}</span></td>
            <td>${shortQuestion}</td>
            <td><small class="text-muted">${escapeHtml(t.llm_provider)}</small></td>
            <td><small class="text-muted">${createdDate}</small></td>
            <td>
              <button class="btn-sm view-ticket-btn" data-id="${t.id}">View Details</button>
            </td>
          </tr>
        `;
      }).join('');

      // Attach view listeners
      document.querySelectorAll('.view-ticket-btn').forEach(btn => {
        btn.addEventListener('click', () => openTicketModal(btn.dataset.id));
      });

    } catch (err) {
      console.error('Error fetching history:', err);
      historyTableBody.innerHTML = `
        <tr>
          <td colspan="6" class="text-center py-4 text-muted">Error loading tickets. Please refresh.</td>
        </tr>
      `;
    }
  }

  // History search filter
  let searchTimeout;
  historySearch.addEventListener('input', () => {
    clearTimeout(searchTimeout);
    searchTimeout = setTimeout(() => {
      fetchTicketsHistory(historySearch.value.trim());
    }, 300);
  });

  refreshHistoryBtn.addEventListener('click', () => {
    fetchTicketsHistory(historySearch.value.trim());
  });

  // 10. Ticket Modal
  async function openTicketModal(ticketId) {
    modal.classList.remove('hidden');
    modalBody.innerHTML = '<p class="text-center py-4 text-muted">Loading ticket details...</p>';

    try {
      const res = await fetch(`/api/tickets/${ticketId}`);
      if (!res.ok) throw new Error('Ticket not found');
      const t = await res.json();

      modalTitle.textContent = `Ticket #${t.ticket_code} - ${t.category}`;
      modalBody.innerHTML = `
        <div style="display: flex; flex-direction: column; gap: 1rem;">
          <div class="meta-banner">
            <span><strong>Ticket:</strong> ${escapeHtml(t.ticket_code)}</span>
            <span><strong>Category:</strong> ${escapeHtml(t.category)}</span>
            <span><strong>Status:</strong> <span class="badge badge-success">${escapeHtml(t.status)}</span></span>
            <span><strong>Engine:</strong> ${escapeHtml(t.llm_provider)}</span>
            <span><strong>Created:</strong> ${new Date(t.created_at).toLocaleString()}</span>
          </div>

          <div>
            <h4 style="font-size: 0.95rem; margin-bottom: 0.35rem; color: var(--slate-900);">Problem Description:</h4>
            <div style="background: var(--slate-50); padding: 0.75rem; border-radius: 6px; border: 1px solid var(--slate-200); font-size: 0.88rem;">
              ${escapeHtml(t.question)}
            </div>
          </div>

          <div>
            <h4 style="font-size: 0.95rem; margin-bottom: 0.35rem; color: var(--slate-900);">AI Troubleshooting Response:</h4>
            <div class="ai-body" style="max-height: 250px;">
              ${renderMarkdown(t.ai_response)}
            </div>
          </div>

          <div>
            <h4 style="font-size: 0.95rem; margin-bottom: 0.35rem; color: var(--slate-900);">Retrieved Knowledge Base Context (RAG):</h4>
            <pre class="rag-pre" style="max-height: 180px;">${escapeHtml(t.retrieved_context)}</pre>
          </div>
        </div>
      `;
    } catch (err) {
      modalBody.innerHTML = `<p class="alert alert-danger">Failed to load ticket details: ${err.message}</p>`;
    }
  }

  function closeModal() {
    modal.classList.add('hidden');
  }

  modalCloseBtn.addEventListener('click', closeModal);
  modalBackdrop.addEventListener('click', closeModal);

  // 11. Fetch Knowledge Base
  async function fetchKnowledgeBase(query = '') {
    try {
      let url = '/api/knowledge-base';
      if (query) {
        url += `?q=${encodeURIComponent(query)}`;
      }
      const res = await fetch(url);
      if (!res.ok) throw new Error('Failed to load knowledge base');
      const items = await res.json();

      if (!items || items.length === 0) {
        kbCardsGrid.innerHTML = '<p class="text-muted" style="grid-column: 1 / -1; text-align: center; padding: 2rem;">No matching knowledge base solutions found.</p>';
        return;
      }

      kbCardsGrid.innerHTML = items.map(item => `
        <div class="kb-card">
          <div class="kb-card-header">
            <h3 class="kb-card-title">${escapeHtml(item.title)}</h3>
            <span class="badge badge-primary">${escapeHtml(item.category)}</span>
          </div>
          <p class="kb-card-problem"><strong>Problem:</strong> ${escapeHtml(item.problem_statement)}</p>
          <div class="kb-card-cause"><strong>Root Cause:</strong> ${escapeHtml(item.root_cause)}</div>
          <div>
            <strong style="font-size: 0.8rem; color: var(--slate-700);">Key Steps:</strong>
            <ul style="padding-left: 1.2rem; font-size: 0.8rem; color: var(--slate-600); margin-top: 0.2rem;">
              ${item.solution_steps.slice(0, 3).map(s => `<li>${escapeHtml(s)}</li>`).join('')}
              ${item.solution_steps.length > 3 ? `<li><em>+ ${item.solution_steps.length - 3} more steps...</em></li>` : ''}
            </ul>
          </div>
          ${item.quick_command ? `
            <div>
              <span style="font-size: 0.75rem; font-weight: 600; color: var(--slate-500);">Quick Command:</span>
              <div class="kb-card-command">${escapeHtml(item.quick_command)}</div>
            </div>
          ` : ''}
        </div>
      `).join('');
    } catch (err) {
      console.error('KB fetch error:', err);
      kbCardsGrid.innerHTML = '<p class="text-muted">Error loading knowledge base articles.</p>';
    }
  }

  kbSearchBtn.addEventListener('click', () => {
    fetchKnowledgeBase(kbSearchInput.value.trim());
  });

  kbSearchInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      fetchKnowledgeBase(kbSearchInput.value.trim());
    }
  });

  // 12. Health Status Fetch
  async function fetchHealthStatus() {
    try {
      const res = await fetch('/api/health');
      if (!res.ok) throw new Error('Health check returned non-200');
      const health = await res.json();

      statusPill.innerHTML = '<span class="pulse-dot"></span> Backend Online';
      statusPill.className = 'pill pill-success';

      providerPill.textContent = 'Engine: ' + health.active_provider;
      kbCountPill.textContent = `KB: ${health.kb_items_count} Solutions`;
    } catch (err) {
      console.warn('Health check failed:', err);
      statusPill.innerHTML = '⚠️ Connecting...';
      statusPill.className = 'pill pill-neutral';
    }
  }

  // Utilities
  function showAlert(msg, type = 'danger') {
    formAlert.textContent = msg;
    formAlert.className = `alert alert-${type}`;
    formAlert.classList.remove('hidden');
  }

  function hideAlert() {
    formAlert.classList.add('hidden');
  }

  function escapeHtml(str) {
    if (!str) return '';
    return str
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  // Safe and clean Markdown Parser
  function renderMarkdown(md) {
    if (!md) return '';
    let html = escapeHtml(md);

    // Code blocks with syntax highlighting appearance: ```...```
    html = html.replace(/```([\s\S]*?)```/g, (match, p1) => {
      return `<pre><code>${p1.trim()}</code></pre>`;
    });

    // Inline code: `code`
    html = html.replace(/`([^`]+)`/g, '<code>$1</code>');

    // Headings: ### Header
    html = html.replace(/^### (.*$)/gim, '<h3>$1</h3>');
    html = html.replace(/^## (.*$)/gim, '<h2>$1</h2>');
    html = html.replace(/^# (.*$)/gim, '<h1>$1</h1>');

    // Bold: **text**
    html = html.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');

    // Italic: *text*
    html = html.replace(/\*([^*]+)\*/g, '<em>$1</em>');

    // Horizontal rules: ---
    html = html.replace(/^---$/gim, '<hr style="border: 0; border-top: 1px solid var(--slate-200); margin: 0.8rem 0;">');

    // Ordered & Unordered list items:
    html = html.replace(/^\s*\*\s+(.*$)/gim, '<li>$1</li>');
    html = html.replace(/^\s*-\s+(.*$)/gim, '<li>$1</li>');
    html = html.replace(/^\s*(\d+)\.\s+(.*$)/gim, '<li>$2</li>');

    // Wrap consecutive list items in <ul> or <ol>
    html = html.replace(/(<li>[\s\S]*?<\/li>)+/g, (match) => `<ul>${match}</ul>`);

    // Line breaks to paragraphs (avoiding double wrapping pre/ul/h)
    const blocks = html.split(/\n\s*\n/);
    return blocks.map(block => {
      block = block.trim();
      if (!block) return '';
      if (block.startsWith('<h') || block.startsWith('<pre') || block.startsWith('<ul') || block.startsWith('<hr')) {
        return block;
      }
      return `<p>${block.replace(/\n/g, '<br>')}</p>`;
    }).join('\n');
  }
});
