import os
from pathlib import Path
from pydantic_settings import BaseSettings, SettingsConfigDict

# Base directory for the project
BASE_DIR = Path(__file__).resolve().parent.parent

class Settings(BaseSettings):
    # LLM Settings
    LLM_PROVIDER: str = "auto"  # "gemini", "groq", or "auto"
    GEMINI_API_KEY: str = ""
    GROQ_API_KEY: str = ""
    GEMINI_MODEL: str = "gemini-1.5-flash"
    GROQ_MODEL: str = "llama-3.1-8b-instant"

    # Database Settings
    DATABASE_URL: str = f"sqlite:///{BASE_DIR / 'it_support.db'}"

    # Knowledge Base
    KB_FILE_PATH: str = str(BASE_DIR / "data" / "knowledge_base.json")

    # Application Settings
    HOST: str = "127.0.0.1"
    PORT: int = 8001
    DEBUG: bool = False
    APP_NAME: str = "AI IT Support Assistant"

    model_config = SettingsConfigDict(
        env_file=str(BASE_DIR / ".env"),
        env_file_encoding="utf-8",
        extra="ignore"
    )

    @property
    def is_gemini_configured(self) -> bool:
        return bool(self.GEMINI_API_KEY and self.GEMINI_API_KEY.strip())

    @property
    def is_groq_configured(self) -> bool:
        return bool(self.GROQ_API_KEY and self.GROQ_API_KEY.strip())

    @property
    def active_provider(self) -> str:
        provider = self.LLM_PROVIDER.lower().strip()
        if provider == "groq" or (provider == "auto" and self.is_groq_configured):
            return "Groq + RAG"
        return "Gemini + RAG"


settings = Settings()
