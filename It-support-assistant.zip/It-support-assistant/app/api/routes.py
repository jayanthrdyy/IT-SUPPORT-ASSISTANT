from typing import Optional, List
from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session

from app.database import get_db
from app.config import settings
from app.schemas import (
    TicketCreate,
    TicketResponse,
    TicketListResponse,
    KnowledgeBaseItem,
    HealthResponse
)
from app.services.ticket_service import ticket_service
from app.services.knowledge_base import kb_service

router = APIRouter(prefix="/api", tags=["IT Support"])

@router.post(
    "/tickets",
    response_model=TicketResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Submit a technical issue and get AI troubleshooting response"
)
def create_ticket(
    ticket_in: TicketCreate,
    db: Session = Depends(get_db)
):
    """
    Submits a user problem, executes TF-IDF vector retrieval against the IT knowledge base,
    sends the prompt to the configured LLM (Gemini or Groq), stores the record in SQL,
    and returns the complete ticket with the troubleshooting guide.
    """
    try:
        ticket = ticket_service.process_and_create_ticket(db=db, ticket_in=ticket_in)
        return ticket
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to process support ticket: {str(e)}"
        )


@router.get(
    "/tickets",
    response_model=TicketListResponse,
    summary="List all support tickets"
)
def list_tickets(
    skip: int = Query(0, ge=0, description="Offset for pagination"),
    limit: int = Query(50, ge=1, le=100, description="Limit records returned"),
    search: Optional[str] = Query(None, description="Search term for tickets"),
    db: Session = Depends(get_db)
):
    """Retrieves stored tickets sorted by newest first."""
    tickets = ticket_service.get_tickets(db=db, skip=skip, limit=limit, search=search)
    total = ticket_service.get_ticket_count(db=db)
    return TicketListResponse(total=total, tickets=tickets)


@router.get(
    "/tickets/{ticket_id}",
    response_model=TicketResponse,
    summary="Get details of a specific ticket"
)
def get_ticket(
    ticket_id: int,
    db: Session = Depends(get_db)
):
    """Retrieves a single ticket by its integer ID."""
    ticket = ticket_service.get_ticket_by_id(db=db, ticket_id=ticket_id)
    if not ticket:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Ticket with ID {ticket_id} not found."
        )
    return ticket


@router.get(
    "/knowledge-base",
    response_model=List[KnowledgeBaseItem],
    summary="Browse knowledge base articles or search using vector retrieval"
)
def get_knowledge_base(
    q: Optional[str] = Query(None, description="Optional search query")
):
    """Returns all pre-indexed IT knowledge base articles, or searches via TF-IDF vector similarity."""
    if q and q.strip():
        results = kb_service.search(q.strip(), top_k=5)
        return [item for item, _ in results]
    return kb_service.get_all_items()


@router.get(
    "/health",
    response_model=HealthResponse,
    summary="Check system status and configuration"
)
def health_check(db: Session = Depends(get_db)):
    """System health endpoint checking SQLite DB connection, KB index, and LLM provider."""
    # Check DB
    db_status = "healthy"
    try:
        db.execute("SELECT 1")
    except Exception:
        # For SQLAlchemy 2.0 with text()
        from sqlalchemy import text
        try:
            db.execute(text("SELECT 1"))
        except Exception as e:
            db_status = f"unhealthy: {str(e)}"

    kb_count = len(kb_service.get_all_items())

    return HealthResponse(
        status="online",
        database_status=db_status,
        kb_items_count=kb_count,
        active_provider=settings.active_provider,
        gemini_configured=settings.is_gemini_configured,
        groq_configured=settings.is_groq_configured
    )
